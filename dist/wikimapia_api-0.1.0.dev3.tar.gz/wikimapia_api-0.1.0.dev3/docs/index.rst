.. wikimapia_api documentation master file, created by
   sphinx-quickstart on Mon Apr 20 00:03:54 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Python Wikimapia API documentation
==================================

Wikimapia_ is an open-content collaborative map project. This library is a
Python (2.7, 3.3 and 3.4) implementation of wikimapia api_.

.. toctree::
   :maxdepth: 2

   tutorial

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _Wikimapia: http://wikimapia.org
.. _api: http://wikimapia.org/api
