.. :changelog:

Changelog
=========

0.1.0.dev2
----------

* API.places.inside now works correctly with cross-tile boundaries
* Minimal logging functionality added
* Minor fixes

0.1.0.dev1
----------

* Initial development version of wikimapia_api
