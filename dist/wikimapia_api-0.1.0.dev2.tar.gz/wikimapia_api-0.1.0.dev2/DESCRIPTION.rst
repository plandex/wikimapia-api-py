Wikimapia API for Python
========================

Wikimapia_ is an open-content collaborative map project. This library is a
Python (2.7, 3.3 and 3.4) implementation of wikimapia api_.

Documentation available in tutorial_.

.. _Wikimapia: http://wikimapia.org
.. _api: http://wikimapia.org/api
.. _tutorial: http://wikimapia-api-py.readthedocs.org/en/latest/tutorial.html
