.. :changelog:

Changelog
=========

0.1.0.dev1
----------

* Initial development version of wikimapia_api
